<template>
  <view class="container" v-if="userinfo">
    <image src="../../static/images/logo.png" mode="" class="logo"></image>
    <view class="info-block">
      <view class="title">{{ userinfo.stuName }}</view>
      <view class="tag">
        <view class="item">已预约：{{ userinfo.used }}小时</view>
        <view class="item">待约课：{{ userinfo.lave }}小时</view>
      </view>
    </view>
    <view class="list-box">
      <view class="list-item">
        <button class="btn" @click="jumpKehu"></button>
        <image src="../../static/images/kehu.png" mode="" class="img"></image>
      </view>
      <view class="list-item">
        <image
          src="../../static/images/yuyue.png"
          mode=""
          class="img"
          @click="jumpCourse"
        ></image>
      </view>
      <view class="list-item">
        <image
          src="../../static/images/jilu.png"
          mode=""
          class="img"
          @click="getPersonalInfo"
        ></image>
      </view>
    </view>
  </view>
</template>

<script>
import { get } from "@/utils/request.js";
import { mapGetters } from "vuex";
export default {
  data() {
    return {};
  },
  computed: {
    ...mapGetters(["userinfo"]),
  },
  onLoad() {
    get("/lessonManagement/personalInfo", {
      unionId: uni.getStorageSync("unionid"),
    }).then((res) => {
      this.$store.commit("setUserinfo", res);
    });
  },
  methods: {
    jumpKehu() {
      wx.openCustomerServiceChat({
        extInfo: {
          url: "https://work.weixin.qq.com/kfid/kfc8cb15992d541ece4",
        },
        corpId: "wwcb10560218a47a01",
        success(res) {},
        fail(err) {
          console.log(err);
        },
      });
    },
    jumpCourse() {
		uni.navigateTo({
		  url: "/pages/formal/formal",
		});
      if (this.userinfo.isAppointment) {
        uni.navigateTo({
          url: "/pages/formal/formal",
        });
      } else {
        uni.navigateTo({
          url: "/pages/reservation/reservation",
        });
      }
    },
    // jumpCourse() {
    // 	uni.navigateTo({
    // 		url: '/pages/formal/formal'
    // 	});
    // },

    //获取个人信息
    getPersonalInfo() {
      get("/lessonManagement/personalInfo", {
        unionId: uni.getStorageSync("unionid"),
      }).then((res) => {
        this.isAppointment = res.isAppointment;
        if (res.isAppointment) {
          if (res.id === 0) {
            uni.showToast({
              title: "请联系客服，确认上课时间",
              icon: "none",
            });
          } else {
            uni.navigateTo({
              url: "/pages/record/record",
            });
          }
        } else {
          uni.showToast({
            title: "您当前暂无预约记录,请联系客服",
            icon: "none",
          });
        }
      });
    },
    //跳转页面
    jumpPage(url) {
      get("/lessonManagement/personalInfo", {
        unionId: uni.getStorageSync("unionid"),
      }).then((res) => {
        if (res.id === 0) {
          uni.showToast({
            title: "请联系客服，确认上课时间",
            icon: "none",
          });
        } else {
          uni.navigateTo({
            url,
          });
        }
      });
    },
  },
};
</script>

<style lang="scss" scoped>
.container {
  display: flex;
  flex-direction: column;
  padding-bottom: 120rpx;
  line-height: 1;

  .logo {
    width: 388rpx;
    height: 180rpx;
    margin: 80rpx auto 0;
  }

  .info-block {
    box-sizing: border-box;
    padding: 50rpx 50rpx;
    box-sizing: border-box;
    margin-left: auto;
    margin-top: 120rpx;
    padding-right: 400rpx;
    background: #eaf5fa url("../../static/images/fxp.png") no-repeat right
      bottom;
    background-size: 112rpx 112rpx;
    border-top-left-radius: 15rpx;
    border-bottom-left-radius: 15rpx;
    box-shadow: 0 0 10rpx rgba(0, 0, 0, 0.1);
    max-width: 85%;
    white-space: nowrap;

    .title {
      margin-bottom: 30rpx;
      color: #333333;
      font-size: 40rpx;
      font-weight: 500;
    }

    .tag {
      display: flex;
      align-items: center;
      gap: 30rpx;

      .item {
        color: #333333;
        font-size: 28rpx;
        font-weight: 400;
      }
    }
  }

  .list-box {
    display: flex;
    flex-direction: column;
    padding: 50rpx 28rpx 0;

    .list-item {
      position: relative;

      .img {
        width: 480rpx;
        height: 200rpx;
      }

      .btn {
        z-index: 10;
        position: absolute;
        left: 0;
        top: 0;
        width: 480rpx;
        height: 200rpx;
        background: transparent;
        background-size: 100% 100%;
        border: none;

        &::after {
          border: none;
        }
      }

      &:nth-child(2) {
        display: flex;
        justify-content: flex-end;
        margin: 50rpx 0;
      }
    }
  }
}
</style>
