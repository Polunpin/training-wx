<template>
	<view>
		<view class="container">
			<image src="../../../static/images/submit-1.png" mode="" class="img"></image>
		</view>
		<view class="submit-box">
			<button type="primary" class="submit" @click="submit">好的</button>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {};
		},
		methods: {
			submit() {
				uni.redirectTo({
					url: "/pages/index/index",
				});
			},
		},
	};
</script>

<style lang="scss">
	.container {
		box-sizing: border-box;
		width: 100%;
		padding: 150rpx 20rpx 0rpx 20rpx;
		display: flex;
		justify-content: center;
		text-align: center;

		.img {
			width: 254px;
			height: 235px;
			flex-shrink: 0;
		}
	}

	.success {
		text-align: center;
	}

	.submit-box {
		height: 44px;
		padding: 200px 60px;
		gap: 6px;
		flex: 1 0 0;

		.submit {
			border-radius: 42px;
			background: #4882C0;
		}
	}
</style>